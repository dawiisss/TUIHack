# TUIHack

 Name: Holiday Assisstant Mobile Application
 
 Technologies used: Hybrid Mobile Development (Ionic 2), MEAN stack (database, routing) , Angular2
 
 Scenario: Hotel and Cruise Experience



Team Members:
- Aqib Bashir
- Dawid Ambroziak
- Darlington Chikanya
- Godfrey Enang
- Qasim Abbasi
