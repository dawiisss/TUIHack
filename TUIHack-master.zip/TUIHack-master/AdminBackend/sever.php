<?php

//connect to sever

$conn=new MongoClient("mongodb://admin:Sigma123@178.62.44.124:27027");

//connectioon to db
$db =$con->Travel;
echo "Successfully connected";
//Access collection

//insert document

?>